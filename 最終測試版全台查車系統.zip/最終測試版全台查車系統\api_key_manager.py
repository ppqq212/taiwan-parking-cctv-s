#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API KEY 管理系統
支援Google API、政府API等各種API KEY的管理和自動配置
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import webbrowser
import requests
from datetime import datetime
import sqlite3

class APIKeyManager:
    def __init__(self, parent_system):
        self.parent = parent_system
        self.api_keys = {}
        self.load_api_keys()
        
    def load_api_keys(self):
        """載入已保存的API KEY"""
        try:
            if os.path.exists("api_keys.json"):
                with open("api_keys.json", "r", encoding="utf-8") as f:
                    self.api_keys = json.load(f)
            else:
                self.api_keys = {
                    "google_maps": "",
                    "google_places": "",
                    "google_geocoding": "",
                    "google_directions": "",
                    "google_distance_matrix": "",
                    "openai": "",
                    "government_taipei": "",
                    "government_ntpc": "",
                    "government_taichung": ""
                }
        except Exception as e:
            print(f"載入API KEY失敗: {e}")
            self.api_keys = {}
    
    def save_api_keys(self):
        """保存API KEY到檔案"""
        try:
            with open("api_keys.json", "w", encoding="utf-8") as f:
                json.dump(self.api_keys, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存API KEY失敗: {e}")
            return False
    
    def create_api_management_tab(self, notebook):
        """創建API管理頁面"""
        api_frame = ttk.Frame(notebook)
        notebook.add(api_frame, text="🔑 API管理")
        
        # 標題
        title_label = tk.Label(api_frame, 
                              text="API KEY 管理中心",
                              font=("微軟正黑體", 16, "bold"),
                              bg=self.parent.colors['bg'], 
                              fg=self.parent.colors['fg'])
        title_label.pack(pady=10)
        
        # 主要功能框架
        main_frame = ttk.Frame(api_frame)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 左側：API KEY 輸入區域
        left_frame = ttk.LabelFrame(main_frame, text="API KEY 配置", padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Google API 區域
        google_frame = ttk.LabelFrame(left_frame, text="Google API", padding=5)
        google_frame.pack(fill=tk.X, pady=5)
        
        # Google Maps API
        self.create_api_input(google_frame, "Google Maps API", "google_maps", 
                             "https://console.cloud.google.com/apis/credentials")
        
        # Google Places API
        self.create_api_input(google_frame, "Google Places API", "google_places",
                             "https://console.cloud.google.com/apis/credentials")
        
        # Google Geocoding API
        self.create_api_input(google_frame, "Google Geocoding API", "google_geocoding",
                             "https://console.cloud.google.com/apis/credentials")
        
        # Google Directions API
        self.create_api_input(google_frame, "Google Directions API", "google_directions",
                             "https://console.cloud.google.com/apis/credentials")
        
        # AI API 區域
        ai_frame = ttk.LabelFrame(left_frame, text="AI API", padding=5)
        ai_frame.pack(fill=tk.X, pady=5)
        
        # OpenAI API
        self.create_api_input(ai_frame, "OpenAI API", "openai",
                             "https://platform.openai.com/api-keys")
        
        # 政府API 區域
        gov_frame = ttk.LabelFrame(left_frame, text="政府API", padding=5)
        gov_frame.pack(fill=tk.X, pady=5)
        
        self.create_api_input(gov_frame, "台北市API", "government_taipei",
                             "https://data.taipei/")
        self.create_api_input(gov_frame, "新北市API", "government_ntpc",
                             "https://data.ntpc.gov.tw/")
        self.create_api_input(gov_frame, "台中市API", "government_taichung",
                             "https://opendata.taichung.gov.tw/")
        
        # 右側：API 狀態和測試區域
        right_frame = ttk.LabelFrame(main_frame, text="API 狀態監控", padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # API 狀態顯示
        self.api_status_text = tk.Text(right_frame, height=15, width=50,
                                      bg=self.parent.colors['entry_bg'],
                                      fg=self.parent.colors['entry_fg'],
                                      font=("微軟正黑體", 9))
        self.api_status_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 控制按鈕
        button_frame = ttk.Frame(right_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(button_frame, text="🔍 測試所有API", 
                  command=self.test_all_apis).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="💾 保存設定", 
                  command=self.save_all_keys).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🔄 重新載入", 
                  command=self.reload_keys).pack(side=tk.LEFT, padx=5)
        
        # 自動配置區域
        auto_config_frame = ttk.LabelFrame(right_frame, text="自動配置", padding=5)
        auto_config_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(auto_config_frame, text="🌐 開啟Google Console", 
                  command=self.open_google_console).pack(side=tk.LEFT, padx=5)
        ttk.Button(auto_config_frame, text="🤖 開啟OpenAI Console", 
                  command=self.open_openai_console).pack(side=tk.LEFT, padx=5)
        ttk.Button(auto_config_frame, text="📋 匯入設定檔", 
                  command=self.import_config).pack(side=tk.LEFT, padx=5)
        
        # 初始化顯示
        self.update_status_display()
    
    def create_api_input(self, parent, label_text, key_name, help_url):
        """創建API KEY輸入框"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=2)
        
        # 標籤
        ttk.Label(frame, text=f"{label_text}:", width=20).pack(side=tk.LEFT)
        
        # 輸入框
        entry = ttk.Entry(frame, width=40, show="*")
        entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 設置初始值
        if key_name in self.api_keys:
            entry.insert(0, self.api_keys[key_name])
        
        # 幫助按鈕
        ttk.Button(frame, text="❓", width=3,
                  command=lambda: self.open_help_url(help_url)).pack(side=tk.RIGHT, padx=2)
        
        # 測試按鈕
        ttk.Button(frame, text="🧪", width=3,
                  command=lambda: self.test_single_api(key_name, entry.get())).pack(side=tk.RIGHT, padx=2)
        
        # 保存到字典
        self.api_key_entries = getattr(self, 'api_key_entries', {})
        self.api_key_entries[key_name] = entry
    
    def open_help_url(self, url):
        """開啟幫助URL"""
        try:
            webbrowser.open(url)
        except Exception as e:
            messagebox.showerror("錯誤", f"無法開啟網址: {e}")
    
    def open_google_console(self):
        """開啟Google Cloud Console"""
        try:
            webbrowser.open("https://console.cloud.google.com/apis/credentials")
            self.update_status("已開啟Google Cloud Console，請創建API KEY")
        except Exception as e:
            messagebox.showerror("錯誤", f"無法開啟Google Console: {e}")
    
    def open_openai_console(self):
        """開啟OpenAI Console"""
        try:
            webbrowser.open("https://platform.openai.com/api-keys")
            self.update_status("已開啟OpenAI Console，請創建API KEY")
        except Exception as e:
            messagebox.showerror("錯誤", f"無法開啟OpenAI Console: {e}")
    
    def import_config(self):
        """匯入設定檔"""
        try:
            file_path = filedialog.askopenfilename(
                title="選擇API設定檔",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if file_path:
                with open(file_path, "r", encoding="utf-8") as f:
                    imported_keys = json.load(f)
                
                # 更新API KEY
                for key, value in imported_keys.items():
                    if key in self.api_key_entries:
                        self.api_key_entries[key].delete(0, tk.END)
                        self.api_key_entries[key].insert(0, value)
                
                self.update_status("設定檔匯入成功")
                messagebox.showinfo("成功", "API設定檔匯入成功！")
                
        except Exception as e:
            messagebox.showerror("錯誤", f"匯入設定檔失敗: {e}")
    
    def test_single_api(self, api_name, api_key):
        """測試單個API"""
        if not api_key:
            self.update_status(f"❌ {api_name}: 未設定API KEY")
            return False
        
        try:
            if api_name.startswith("google"):
                return self.test_google_api(api_name, api_key)
            elif api_name == "openai":
                return self.test_openai_api(api_key)
            else:
                return self.test_government_api(api_name, api_key)
        except Exception as e:
            self.update_status(f"❌ {api_name}: 測試失敗 - {e}")
            return False
    
    def test_google_api(self, api_name, api_key):
        """測試Google API"""
        try:
            # 測試Google Maps API
            test_url = "https://maps.googleapis.com/maps/api/geocode/json"
            params = {
                "address": "台北市",
                "key": api_key
            }
            
            response = requests.get(test_url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    self.update_status(f"✅ {api_name}: 連接成功")
                    return True
                else:
                    self.update_status(f"❌ {api_name}: API回應錯誤 - {data.get('status')}")
                    return False
            else:
                self.update_status(f"❌ {api_name}: HTTP錯誤 - {response.status_code}")
                return False
                
        except Exception as e:
            self.update_status(f"❌ {api_name}: 連接失敗 - {e}")
            return False
    
    def test_openai_api(self, api_key):
        """測試OpenAI API"""
        try:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 簡單的測試請求
            test_data = {
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 5
            }
            
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=test_data,
                timeout=10
            )
            
            if response.status_code == 200:
                self.update_status("✅ OpenAI API: 連接成功")
                return True
            else:
                self.update_status(f"❌ OpenAI API: 錯誤 - {response.status_code}")
                return False
                
        except Exception as e:
            self.update_status(f"❌ OpenAI API: 連接失敗 - {e}")
            return False
    
    def test_government_api(self, api_name, api_key):
        """測試政府API"""
        try:
            # 這裡可以根據不同的政府API進行測試
            self.update_status(f"✅ {api_name}: 已設定 (需要實際API進行測試)")
            return True
        except Exception as e:
            self.update_status(f"❌ {api_name}: 測試失敗 - {e}")
            return False
    
    def test_all_apis(self):
        """測試所有API"""
        self.update_status("🔍 開始測試所有API...")
        
        success_count = 0
        total_count = 0
        
        for key_name, entry in self.api_key_entries.items():
            api_key = entry.get()
            total_count += 1
            
            if api_key:
                if self.test_single_api(key_name, api_key):
                    success_count += 1
        
        self.update_status(f"📊 測試完成: {success_count}/{total_count} 個API可用")
        
        if success_count == total_count:
            messagebox.showinfo("成功", "所有API測試通過！")
        else:
            messagebox.showwarning("警告", f"有 {total_count - success_count} 個API需要檢查")
    
    def save_all_keys(self):
        """保存所有API KEY"""
        try:
            for key_name, entry in self.api_key_entries.items():
                self.api_keys[key_name] = entry.get()
            
            if self.save_api_keys():
                self.update_status("💾 API KEY已保存")
                messagebox.showinfo("成功", "API KEY保存成功！")
            else:
                messagebox.showerror("錯誤", "保存失敗，請檢查檔案權限")
                
        except Exception as e:
            messagebox.showerror("錯誤", f"保存失敗: {e}")
    
    def reload_keys(self):
        """重新載入API KEY"""
        self.load_api_keys()
        for key_name, entry in self.api_key_entries.items():
            if key_name in self.api_keys:
                entry.delete(0, tk.END)
                entry.insert(0, self.api_keys[key_name])
        self.update_status("🔄 API KEY已重新載入")
    
    def update_status(self, message):
        """更新狀態顯示"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        status_message = f"[{timestamp}] {message}\n"
        
        self.api_status_text.insert(tk.END, status_message)
        self.api_status_text.see(tk.END)
        self.api_status_text.update()
    
    def update_status_display(self):
        """更新狀態顯示"""
        self.api_status_text.delete(1.0, tk.END)
        
        status_info = f"""
🔑 API KEY 管理中心
⏰ 最後更新: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📋 已配置的API:
"""
        
        for key_name, api_key in self.api_keys.items():
            if api_key:
                status_info += f"✅ {key_name}: 已設定\n"
            else:
                status_info += f"❌ {key_name}: 未設定\n"
        
        status_info += f"""
💡 使用說明:
1. 在左側輸入框中輸入您的API KEY
2. 點擊 ❓ 按鈕開啟對應的API管理頁面
3. 點擊 🧪 按鈕測試單個API
4. 點擊 🔍 測試所有API 進行全面測試
5. 點擊 💾 保存設定 保存所有API KEY

🌐 快速連結:
• Google Cloud Console: https://console.cloud.google.com/apis/credentials
• OpenAI Console: https://platform.openai.com/api-keys
• 台北市開放資料: https://data.taipei/
• 新北市開放資料: https://data.ntpc.gov.tw/
        """
        
        self.api_status_text.insert(tk.END, status_info)
    
    def get_api_key(self, key_name):
        """獲取指定的API KEY"""
        return self.api_keys.get(key_name, "")
    
    def is_api_configured(self, key_name):
        """檢查API是否已配置"""
        return bool(self.api_keys.get(key_name, ""))
