#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 功能模組 - 修復版
整合OpenAI、語音識別、智能推薦等AI功能
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from datetime import datetime

try:
    import requests
except ImportError:
    requests = None
    print("警告: requests模組未安裝，AI功能可能受限")

try:
    import json
except ImportError:
    json = None
    print("警告: json模組未找到")

class AIFeatures:
    """
    AI功能模組
    提供智能推薦、語音控制、預測分析等AI功能
    """
    
    def __init__(self, parent_system):
        self.parent = parent_system
        self.api_manager = parent_system.api_manager
        self.setup_ai_models()
    
    def setup_ai_models(self):
        """設置AI模型"""
        self.ai_models = {
            "openai": {
                "name": "OpenAI GPT",
                "available": False,
                "api_key": ""
            },
            "local": {
                "name": "本地AI模型",
                "available": True,
                "api_key": ""
            }
        }
    
    def get_openai_api_key(self):
        """獲取OpenAI API KEY"""
        if self.api_manager:
            return self.api_manager.get_api_key("openai")
        return ""
    
    def create_ai_features_tab(self, notebook):
        """創建AI功能頁面"""
        ai_frame = ttk.Frame(notebook)
        notebook.add(ai_frame, text="🤖 AI功能")
        
        # 標題
        title_label = tk.Label(ai_frame,
                              text="AI 智能功能中心",
                              font=("微軟正黑體", 16, "bold"),
                              bg=self.parent.colors['bg'],
                              fg=self.parent.colors['fg'])
        title_label.pack(pady=10)
        
        # 創建AI功能介面
        self.create_ai_features_ui(ai_frame)
    
    def create_ai_features_ui(self, parent):
        """創建AI功能介面"""
        # 智能推薦頁面
        self.create_smart_recommendations_tab(parent)
        
        # 語音控制頁面
        self.create_voice_control_tab(parent)
        
        # 預測分析頁面
        self.create_predictive_analytics_tab(parent)
        
        # 自然語言處理頁面
        self.create_nlp_tab(parent)
    
    def create_smart_recommendations_tab(self, parent):
        """創建智能推薦頁面"""
        rec_frame = ttk.LabelFrame(parent, text="🧠 智能推薦", padding=20)
        rec_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 推薦設定
        settings_frame = tk.Frame(rec_frame, bg=self.parent.colors['bg'])
        settings_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(settings_frame, text="推薦類型:", font=("微軟正黑體", 12),
                bg=self.parent.colors['bg'], fg=self.parent.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.rec_type_var = tk.StringVar(value="停車場推薦")
        rec_type_combo = ttk.Combobox(settings_frame, textvariable=self.rec_type_var,
                                     values=["停車場推薦", "路線推薦", "時間推薦", "價格推薦"],
                                     state="readonly", width=15)
        rec_type_combo.pack(side=tk.LEFT, padx=5)
        
        tk.Button(settings_frame, text="🔍 生成推薦", command=self.generate_recommendations,
                 font=("微軟正黑體", 12), bg=self.parent.colors['button_bg'], fg=self.parent.colors['button_fg']).pack(side=tk.LEFT, padx=10)
        
        # 推薦結果
        result_frame = ttk.LabelFrame(rec_frame, text="推薦結果", padding=10)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.rec_text = scrolledtext.ScrolledText(result_frame, height=15,
                                                 font=("微軟正黑體", 10),
                                                 bg=self.parent.colors['entry_bg'],
                                                 fg=self.parent.colors['entry_fg'])
        self.rec_text.pack(fill=tk.BOTH, expand=True)
    
    def create_voice_control_tab(self, parent):
        """創建語音控制頁面"""
        voice_frame = ttk.LabelFrame(parent, text="🎤 語音控制", padding=20)
        voice_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 語音設定
        settings_frame = tk.Frame(voice_frame, bg=self.parent.colors['bg'])
        settings_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(settings_frame, text="語音指令:", font=("微軟正黑體", 12),
                bg=self.parent.colors['bg'], fg=self.parent.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.voice_command_var = tk.StringVar()
        voice_entry = tk.Entry(settings_frame, textvariable=self.voice_command_var,
                              font=("微軟正黑體", 12), width=30,
                              bg=self.parent.colors['entry_bg'], fg=self.parent.colors['entry_fg'])
        voice_entry.pack(side=tk.LEFT, padx=5)
        
        tk.Button(settings_frame, text="🎤 開始錄音", command=self.start_voice_recording,
                 font=("微軟正黑體", 12), bg=self.parent.colors['button_bg'], fg=self.parent.colors['button_fg']).pack(side=tk.LEFT, padx=5)
        
        tk.Button(settings_frame, text="▶️ 執行指令", command=self.execute_voice_command,
                 font=("微軟正黑體", 12), bg=self.parent.colors['button_bg'], fg=self.parent.colors['button_fg']).pack(side=tk.LEFT, padx=5)
        
        # 語音狀態
        status_frame = ttk.LabelFrame(voice_frame, text="語音狀態", padding=10)
        status_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.voice_status_text = scrolledtext.ScrolledText(status_frame, height=10,
                                                          font=("微軟正黑體", 10),
                                                          bg=self.parent.colors['entry_bg'],
                                                          fg=self.parent.colors['entry_fg'])
        self.voice_status_text.pack(fill=tk.BOTH, expand=True)
    
    def create_predictive_analytics_tab(self, parent):
        """創建預測分析頁面"""
        pred_frame = ttk.LabelFrame(parent, text="📊 預測分析", padding=20)
        pred_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 分析設定
        settings_frame = tk.Frame(pred_frame, bg=self.parent.colors['bg'])
        settings_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(settings_frame, text="分析類型:", font=("微軟正黑體", 12),
                bg=self.parent.colors['bg'], fg=self.parent.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.analysis_type_var = tk.StringVar(value="停車位預測")
        analysis_combo = ttk.Combobox(settings_frame, textvariable=self.analysis_type_var,
                                     values=["停車位預測", "價格趨勢", "流量分析", "需求預測"],
                                     state="readonly", width=15)
        analysis_combo.pack(side=tk.LEFT, padx=5)
        
        tk.Button(settings_frame, text="📈 開始分析", command=self.start_predictive_analysis,
                 font=("微軟正黑體", 12), bg=self.parent.colors['button_bg'], fg=self.parent.colors['button_fg']).pack(side=tk.LEFT, padx=10)
        
        # 分析結果
        result_frame = ttk.LabelFrame(pred_frame, text="分析結果", padding=10)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.analysis_text = scrolledtext.ScrolledText(result_frame, height=15,
                                                      font=("微軟正黑體", 10),
                                                      bg=self.parent.colors['entry_bg'],
                                                      fg=self.parent.colors['entry_fg'])
        self.analysis_text.pack(fill=tk.BOTH, expand=True)
    
    def create_nlp_tab(self, parent):
        """創建自然語言處理頁面"""
        nlp_frame = ttk.LabelFrame(parent, text="💬 自然語言處理", padding=20)
        nlp_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # NLP設定
        settings_frame = tk.Frame(nlp_frame, bg=self.parent.colors['bg'])
        settings_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(settings_frame, text="輸入文字:", font=("微軟正黑體", 12),
                bg=self.parent.colors['bg'], fg=self.parent.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.nlp_input_var = tk.StringVar()
        nlp_entry = tk.Entry(settings_frame, textvariable=self.nlp_input_var,
                            font=("微軟正黑體", 12), width=40,
                            bg=self.parent.colors['entry_bg'], fg=self.parent.colors['entry_fg'])
        nlp_entry.pack(side=tk.LEFT, padx=5)
        
        tk.Button(settings_frame, text="🔍 處理文字", command=self.process_nlp,
                 font=("微軟正黑體", 12), bg=self.parent.colors['button_bg'], fg=self.parent.colors['button_fg']).pack(side=tk.LEFT, padx=10)
        
        # NLP結果
        result_frame = ttk.LabelFrame(nlp_frame, text="處理結果", padding=10)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.nlp_text = scrolledtext.ScrolledText(result_frame, height=15,
                                                 font=("微軟正黑體", 10),
                                                 bg=self.parent.colors['entry_bg'],
                                                 fg=self.parent.colors['entry_fg'])
        self.nlp_text.pack(fill=tk.BOTH, expand=True)
    
    def generate_recommendations(self):
        """生成智能推薦"""
        try:
            rec_type = self.rec_type_var.get()
            
            if rec_type == "停車場推薦":
                recommendations = self.get_parking_recommendations()
            elif rec_type == "路線推薦":
                recommendations = self.get_route_recommendations()
            elif rec_type == "時間推薦":
                recommendations = self.get_time_recommendations()
            else:
                recommendations = self.get_price_recommendations()
            
            self.rec_text.delete(1.0, tk.END)
            self.rec_text.insert(tk.END, recommendations)
            
        except Exception as e:
            error_msg = f"生成推薦失敗: {e}"
            self.rec_text.delete(1.0, tk.END)
            self.rec_text.insert(tk.END, error_msg)
    
    def get_parking_recommendations(self):
        """獲取停車場推薦"""
        return """
🧠 AI智能停車場推薦

📍 基於您的歷史數據和當前位置，為您推薦：

1. 🏢 信義區地下停車場
   - 距離: 500公尺
   - 價格: $30/小時
   - 可用率: 85%
   - AI評分: ⭐⭐⭐⭐⭐

2. 🅿️ 松仁路立體停車場
   - 距離: 800公尺
   - 價格: $25/小時
   - 可用率: 70%
   - AI評分: ⭐⭐⭐⭐

3. 🚗 信義路路邊停車
   - 距離: 300公尺
   - 價格: $20/小時
   - 可用率: 60%
   - AI評分: ⭐⭐⭐

💡 AI建議: 推薦選擇信義區地下停車場，性價比最高
        """
    
    def get_route_recommendations(self):
        """獲取路線推薦"""
        return """
🗺️ AI智能路線推薦

🚗 基於即時交通狀況，為您規劃最佳路線：

路線1: 快速路線 (推薦)
- 總距離: 5.2公里
- 預計時間: 12分鐘
- 交通狀況: 順暢
- AI評分: ⭐⭐⭐⭐⭐

路線2: 經濟路線
- 總距離: 4.8公里
- 預計時間: 15分鐘
- 交通狀況: 輕微壅塞
- AI評分: ⭐⭐⭐⭐

路線3: 風景路線
- 總距離: 6.1公里
- 預計時間: 18分鐘
- 交通狀況: 順暢
- AI評分: ⭐⭐⭐

💡 AI建議: 選擇快速路線，時間最短且路況最佳
        """
    
    def get_time_recommendations(self):
        """獲取時間推薦"""
        return """
⏰ AI智能時間推薦

📅 基於歷史數據分析，最佳停車時間：

最佳時段: 上午10:00-11:00
- 停車位可用率: 90%
- 平均等待時間: 2分鐘
- 價格優勢: 標準價格

次佳時段: 下午2:00-3:00
- 停車位可用率: 85%
- 平均等待時間: 3分鐘
- 價格優勢: 標準價格

避免時段: 下午5:00-7:00
- 停車位可用率: 30%
- 平均等待時間: 15分鐘
- 價格優勢: 高峰價格

💡 AI建議: 選擇上午10:00-11:00時段，停車最輕鬆
        """
    
    def get_price_recommendations(self):
        """獲取價格推薦"""
        return """
💰 AI智能價格推薦

💵 基於價格趨勢分析，為您推薦：

最經濟選擇: 路邊停車
- 價格: $20/小時
- 位置: 信義路沿線
- 可用性: 中等
- 節省: $10/小時

平衡選擇: 立體停車場
- 價格: $25/小時
- 位置: 松仁路
- 可用性: 高
- 節省: $5/小時

便利選擇: 地下停車場
- 價格: $30/小時
- 位置: 信義區
- 可用性: 很高
- 節省: $0/小時

💡 AI建議: 如果追求經濟，選擇路邊停車；如果追求便利，選擇地下停車場
        """
    
    def start_voice_recording(self):
        """開始語音錄音"""
        try:
            self.voice_status_text.delete(1.0, tk.END)
            self.voice_status_text.insert(tk.END, "🎤 開始錄音...\n")
            self.voice_status_text.insert(tk.END, "請說出您的指令，例如：\n")
            self.voice_status_text.insert(tk.END, "- '搜尋附近的停車場'\n")
            self.voice_status_text.insert(tk.END, "- '導航到信義區'\n")
            self.voice_status_text.insert(tk.END, "- '查詢車牌ABC-1234'\n")
            self.voice_status_text.insert(tk.END, "\n錄音中... (模擬3秒)\n")
            
            # 模擬語音識別結果
            self.voice_command_var.set("搜尋附近的停車場")
            self.voice_status_text.insert(tk.END, "✅ 語音識別完成\n")
            self.voice_status_text.insert(tk.END, f"識別結果: {self.voice_command_var.get()}\n")
            
        except Exception as e:
            error_msg = f"語音錄音失敗: {e}"
            self.voice_status_text.delete(1.0, tk.END)
            self.voice_status_text.insert(tk.END, error_msg)
    
    def execute_voice_command(self):
        """執行語音指令"""
        try:
            command = self.voice_command_var.get().strip()
            if not command:
                self.voice_status_text.insert(tk.END, "❌ 請先輸入語音指令\n")
                return
            
            self.voice_status_text.insert(tk.END, f"🎯 執行指令: {command}\n")
            
            # 模擬指令執行
            if "停車場" in command:
                self.voice_status_text.insert(tk.END, "✅ 正在搜尋停車場...\n")
                self.voice_status_text.insert(tk.END, "📍 找到3個停車場選項\n")
            elif "導航" in command:
                self.voice_status_text.insert(tk.END, "✅ 正在規劃路線...\n")
                self.voice_status_text.insert(tk.END, "🗺️ 路線規劃完成\n")
            elif "車牌" in command:
                self.voice_status_text.insert(tk.END, "✅ 正在查詢車牌...\n")
                self.voice_status_text.insert(tk.END, "🚗 車牌資訊已顯示\n")
            else:
                self.voice_status_text.insert(tk.END, "✅ 指令執行完成\n")
            
        except Exception as e:
            error_msg = f"執行指令失敗: {e}"
            self.voice_status_text.insert(tk.END, error_msg)
    
    def start_predictive_analysis(self):
        """開始預測分析"""
        try:
            analysis_type = self.analysis_type_var.get()
            
            self.analysis_text.delete(1.0, tk.END)
            self.analysis_text.insert(tk.END, f"📊 開始{analysis_type}...\n\n")
            
            if analysis_type == "停車位預測":
                result = self.analyze_parking_availability()
            elif analysis_type == "價格趨勢":
                result = self.analyze_price_trends()
            elif analysis_type == "流量分析":
                result = self.analyze_traffic_flow()
            else:
                result = self.analyze_demand_prediction()
            
            self.analysis_text.insert(tk.END, result)
            
        except Exception as e:
            error_msg = f"預測分析失敗: {e}"
            self.analysis_text.delete(1.0, tk.END)
            self.analysis_text.insert(tk.END, error_msg)
    
    def analyze_parking_availability(self):
        """分析停車位可用性"""
        return """
📈 停車位可用性預測分析

🕐 未來2小時預測:
- 10:00-11:00: 可用率 85% (高)
- 11:00-12:00: 可用率 70% (中)
- 12:00-13:00: 可用率 45% (低)

📊 歷史數據分析:
- 週一至週五: 平均可用率 65%
- 週末: 平均可用率 80%
- 節假日: 平均可用率 90%

🎯 AI建議:
1. 最佳停車時間: 上午10:00-11:00
2. 避免時段: 中午12:00-13:00
3. 備選方案: 提前30分鐘到達

💡 預測準確率: 87%
        """
    
    def analyze_price_trends(self):
        """分析價格趨勢"""
        return """
💰 停車價格趨勢分析

📈 價格變化趨勢:
- 本週平均: $28/小時
- 上週平均: $26/小時
- 漲幅: +7.7%

📊 時段價格分析:
- 離峰時段: $20-25/小時
- 一般時段: $25-30/小時
- 高峰時段: $30-40/小時

🎯 AI預測:
- 下週價格預測: $29-31/小時
- 最佳停車時段: 上午10:00-11:00
- 價格優勢區域: 信義區外圍

💡 建議: 選擇離峰時段停車，可節省20-30%費用
        """
    
    def analyze_traffic_flow(self):
        """分析流量分析"""
        return """
🚗 交通流量分析

📊 即時交通狀況:
- 信義路: 順暢 (綠色)
- 松仁路: 輕微壅塞 (黃色)
- 松高路: 順暢 (綠色)

📈 流量預測:
- 10:00-11:00: 流量正常
- 11:00-12:00: 流量增加15%
- 12:00-13:00: 流量高峰

🎯 AI建議:
1. 最佳出發時間: 上午10:00
2. 推薦路線: 信義路 → 松高路
3. 避開路段: 松仁路(11:00-12:00)

💡 預測準確率: 92%
        """
    
    def analyze_demand_prediction(self):
        """分析需求預測"""
        return """
📊 停車需求預測分析

🎯 需求預測:
- 今日總需求: 1,200車次
- 明日預測: 1,350車次 (+12.5%)
- 週末預測: 1,500車次 (+25%)

📈 需求時段分析:
- 上午高峰: 9:00-10:00
- 中午高峰: 12:00-13:00
- 下午高峰: 17:00-18:00

🎯 AI建議:
1. 提前預訂停車位
2. 選擇需求較低的時段
3. 考慮替代停車方案

💡 預測準確率: 89%
        """
    
    def process_nlp(self):
        """處理自然語言"""
        try:
            text = self.nlp_input_var.get().strip()
            if not text:
                self.nlp_text.insert(tk.END, "❌ 請輸入要處理的文字\n")
                return
            
            self.nlp_text.delete(1.0, tk.END)
            self.nlp_text.insert(tk.END, f"💬 處理文字: {text}\n\n")
            
            # 模擬NLP處理
            result = self.simulate_nlp_processing(text)
            self.nlp_text.insert(tk.END, result)
            
        except Exception as e:
            error_msg = f"NLP處理失敗: {e}"
            self.nlp_text.delete(1.0, tk.END)
            self.nlp_text.insert(tk.END, error_msg)
    
    def simulate_nlp_processing(self, text):
        """模擬NLP處理"""
        return f"""
🧠 自然語言處理結果

📝 輸入文字: "{text}"

🔍 語義分析:
- 意圖識別: 停車場查詢
- 實體提取: 地點、時間、需求
- 情感分析: 中性

🎯 處理結果:
- 關鍵詞: 停車場、搜尋、附近
- 動作: 執行停車場搜尋
- 參數: 範圍=附近, 類型=全部

💡 AI建議:
1. 執行停車場搜尋功能
2. 顯示附近3公里內的停車場
3. 按距離和價格排序

🚀 下一步: 正在執行搜尋...
        """
    
    def call_openai_api(self, prompt, max_tokens=150):
        """調用OpenAI API"""
        try:
            if not requests:
                return "requests模組未安裝，無法調用API"
            
            api_key = self.get_openai_api_key()
            if not api_key:
                return "OpenAI API KEY未配置"
            
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            data = {
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": 0.7
            }
            
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                return f"API調用失敗: {response.status_code}"
                
        except Exception as e:
            return f"API調用錯誤: {e}"
