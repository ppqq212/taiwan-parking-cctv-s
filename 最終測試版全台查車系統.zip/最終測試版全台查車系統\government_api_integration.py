#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
政府API整合模組 - 修復版
整合全台各縣市政府停車場API和監理站API
"""

import sqlite3
import hashlib
import base64
from datetime import datetime
import concurrent.futures
from functools import lru_cache

try:
    import requests
except ImportError:
    requests = None
    print("警告: requests模組未安裝，政府API功能可能受限")

class GovernmentAPIIntegration:
    """
    政府API整合模組
    整合全台各縣市政府停車場API和監理站API
    """
    
    def __init__(self, db_path="multi_table_parking.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        # 快取設定
        self.cache_duration = 300  # 5分鐘快取
        self.cache = {}
        self.max_workers = 5
        self.session = None
        
        if requests:
            self.session = requests.Session()
            self.session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
        
        # 初始化API配置
        self.setup_apis()
    
    def setup_apis(self):
        """設置API配置"""
        self.regional_apis = {
            "台北市": {
                "base_url": "https://api.taipei.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 1000,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "新北市": {
                "base_url": "https://api.ntpc.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 800,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "桃園市": {
                "base_url": "https://api.tycg.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 600,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "台中市": {
                "base_url": "https://api.taichung.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 700,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "台南市": {
                "base_url": "https://api.tainan.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 500,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "高雄市": {
                "base_url": "https://api.kcg.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 600,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "基隆市": {
                "base_url": "https://api.klcg.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 300,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "新竹市": {
                "base_url": "https://api.hccg.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 300,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "嘉義市": {
                "base_url": "https://api.chiayi.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 300,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "花蓮縣": {
                "base_url": "https://api.hl.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 500,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "宜蘭縣": {
                "base_url": "https://api.e-land.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 500,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            },
            "台東縣": {
                "base_url": "https://api.taitung.gov.tw",
                "parking_api": "/parking/realtime",
                "payment_api": "/parking/payment",
                "rate_limit": 500,
                "api_key": "",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer YOUR_API_KEY"
                }
            }
        }
        
        # 監理站API配置
        self.dmv_apis = {
            "台北監理站": {
                "base_url": "https://api.mvdis.gov.tw",
                "vehicle_api": "/vehicle/query",
                "rate_limit": 100,
                "api_key": ""
            },
            "台中監理站": {
                "base_url": "https://api.mvdis.gov.tw",
                "vehicle_api": "/vehicle/query",
                "rate_limit": 100,
                "api_key": ""
            },
            "高雄監理站": {
                "base_url": "https://api.mvdis.gov.tw",
                "vehicle_api": "/vehicle/query",
                "rate_limit": 100,
                "api_key": ""
            }
        }
    
    def _get_cache_key(self, url, params=None):
        """生成快取鍵值"""
        key_string = f"{url}_{str(params)}"
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _is_cache_valid(self, cache_key):
        """檢查快取是否有效"""
        if cache_key not in self.cache:
            return False
        
        cache_time = self.cache[cache_key].get('timestamp', 0)
        current_time = datetime.now().timestamp()
        return (current_time - cache_time) < self.cache_duration
    
    def _get_cached_data(self, cache_key):
        """獲取快取數據"""
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key].get('data')
        return None
    
    def _set_cache_data(self, cache_key, data):
        """設置快取數據"""
        self.cache[cache_key] = {
            'data': data,
            'timestamp': datetime.now().timestamp()
        }
    
    def _make_request(self, url, params=None, headers=None, timeout=10):
        """發送API請求"""
        if not requests or not self.session:
            return None
        
        cache_key = self._get_cache_key(url, params)
        cached_data = self._get_cached_data(cache_key)
        if cached_data:
            return cached_data
        
        try:
            response = self.session.get(
                url,
                params=params,
                headers=headers,
                timeout=timeout
            )
            response.raise_for_status()
            data = response.json()
            self._set_cache_data(cache_key, data)
            return data
        except requests.RequestException as e:
            print(f"API請求失敗: {url}, 錯誤: {e}")
            return None
    
    def _parallel_requests(self, requests_list):
        """並行處理多個API請求"""
        if not requests:
            return []
        
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_request = {
                executor.submit(self._make_request, req['url'], req.get('params'), req.get('headers')): req
                for req in requests_list
            }
            
            for future in concurrent.futures.as_completed(future_to_request):
                request = future_to_request[future]
                try:
                    result = future.result()
                    if result:
                        results.append({
                            'region': request.get('region', ''),
                            'data': result
                        })
                except Exception as e:
                    print(f"並行請求失敗: {e}")
        
        return results
    
    @lru_cache(maxsize=128)
    def get_parking_data(self, region):
        """獲取指定地區的停車場數據"""
        if region not in self.regional_apis:
            return {"error": f"不支援的地區: {region}"}
        
        api_config = self.regional_apis[region]
        url = f"{api_config['base_url']}{api_config['parking_api']}"
        
        try:
            data = self._make_request(
                url,
                headers=api_config.get('headers', {}),
                timeout=10
            )
            
            if data:
                return self._parse_parking_data(data, region)
            else:
                return {"error": f"無法獲取{region}停車場數據"}
                
        except Exception as e:
            return {"error": f"獲取{region}停車場數據失敗: {e}"}
    
    def _parse_parking_data(self, data, region):
        """解析停車場數據"""
        try:
            parking_list = []
            if isinstance(data, dict) and 'data' in data:
                raw_data = data['data']
            elif isinstance(data, list):
                raw_data = data
            else:
                raw_data = []
            
            for item in raw_data:
                parking_info = {
                    'name': item.get('name', '未知停車場'),
                    'address': item.get('address', '地址未知'),
                    'total_spaces': item.get('total_spaces', 0),
                    'available_spaces': item.get('available_spaces', 0),
                    'hourly_rate': item.get('hourly_rate', 0),
                    'region': region,
                    'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                parking_list.append(parking_info)
            
            return {
                'region': region,
                'parking_list': parking_list,
                'count': len(parking_list),
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            return {"error": f"解析{region}停車場數據失敗: {e}"}
    
    def get_all_regions_parking_data(self):
        """獲取所有地區的停車場數據"""
        requests_list = []
        for region, config in self.regional_apis.items():
            url = f"{config['base_url']}{config['parking_api']}"
            requests_list.append({
                'url': url,
                'params': None,
                'headers': config.get('headers', {}),
                'region': region
            })
        
        results = self._parallel_requests(requests_list)
        return results
    
    def search_parking_by_location(self, location, radius=1000):
        """根據位置搜尋停車場"""
        try:
            # 模擬根據位置搜尋停車場
            parking_data = []
            
            # 搜尋附近各縣市的停車場
            for region in self.regional_apis.keys():
                region_data = self.get_parking_data(region)
                if 'parking_list' in region_data:
                    for parking in region_data['parking_list']:
                        # 模擬距離計算
                        distance = self._calculate_distance(location, parking.get('address', ''))
                        if distance <= radius:
                            parking['distance'] = distance
                            parking_data.append(parking)
            
            # 按距離排序
            parking_data.sort(key=lambda x: x.get('distance', float('inf')))
            
            return {
                'location': location,
                'radius': radius,
                'parking_list': parking_data,
                'count': len(parking_data)
            }
            
        except Exception as e:
            return {"error": f"搜尋停車場失敗: {e}"}
    
    def _calculate_distance(self, location1, location2):
        """計算兩個位置之間的距離（模擬）"""
        # 這裡是模擬距離計算，實際應用中應該使用真實的地理計算
        return hash(location1 + location2) % 2000
    
    def get_vehicle_info(self, plate_number):
        """查詢車輛資訊"""
        try:
            # 模擬監理站API查詢
            dmv_data = {
                'plate_number': plate_number,
                'owner_name': '模擬車主',
                'vehicle_type': '轎車',
                'registration_date': '2020-01-01',
                'status': '正常',
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            return dmv_data
            
        except Exception as e:
            return {"error": f"查詢車輛資訊失敗: {e}"}
    
    def get_parking_payment_status(self, plate_number):
        """查詢停車費繳費狀態"""
        try:
            # 模擬停車費查詢
            payment_data = {
                'plate_number': plate_number,
                'unpaid_amount': 0,
                'last_payment_date': '2024-01-01',
                'status': '已繳清',
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            return payment_data
            
        except Exception as e:
            return {"error": f"查詢停車費狀態失敗: {e}"}
    
    def get_traffic_violations(self, plate_number):
        """查詢交通違規記錄"""
        try:
            # 模擬違規記錄查詢
            violations = []
            
            return {
                'plate_number': plate_number,
                'violations': violations,
                'count': len(violations),
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            return {"error": f"查詢交通違規記錄失敗: {e}"}
    
    def get_comprehensive_vehicle_info(self, plate_number):
        """獲取車輛綜合資訊"""
        try:
            # 獲取車輛基本資訊
            vehicle_info = self.get_vehicle_info(plate_number)
            
            # 獲取停車費狀態
            payment_status = self.get_parking_payment_status(plate_number)
            
            # 獲取違規記錄
            violations = self.get_traffic_violations(plate_number)
            
            return {
                'plate_number': plate_number,
                'vehicle_info': vehicle_info,
                'payment_status': payment_status,
                'violations': violations,
                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            return {"error": f"獲取車輛綜合資訊失敗: {e}"}
    
    def save_parking_data_to_db(self, parking_data):
        """將停車場數據保存到資料庫"""
        try:
            if 'parking_list' in parking_data:
                for parking in parking_data['parking_list']:
                    self.cursor.execute('''
                        INSERT OR REPLACE INTO eastern_parking_data 
                        (region, parking_name, address, total_spaces, available_spaces, hourly_rate)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        parking.get('region', ''),
                        parking.get('name', ''),
                        parking.get('address', ''),
                        parking.get('total_spaces', 0),
                        parking.get('available_spaces', 0),
                        parking.get('hourly_rate', 0)
                    ))
            
            self.conn.commit()
            return {"success": True, "message": "停車場數據已保存"}
            
        except Exception as e:
            return {"error": f"保存停車場數據失敗: {e}"}
    
    def get_api_status(self):
        """獲取API狀態"""
        status = {
            'regional_apis': {},
            'dmv_apis': {},
            'cache_status': {
                'cache_size': len(self.cache),
                'cache_duration': self.cache_duration
            },
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # 檢查各地區API狀態
        for region, config in self.regional_apis.items():
            status['regional_apis'][region] = {
                'base_url': config['base_url'],
                'rate_limit': config['rate_limit'],
                'api_key_configured': bool(config.get('api_key')),
                'status': 'available'
            }
        
        # 檢查監理站API狀態
        for station, config in self.dmv_apis.items():
            status['dmv_apis'][station] = {
                'base_url': config['base_url'],
                'rate_limit': config['rate_limit'],
                'api_key_configured': bool(config.get('api_key')),
                'status': 'available'
            }
        
        return status
    
    def clear_cache(self):
        """清除快取"""
        self.cache.clear()
        return {"success": True, "message": "快取已清除"}
    
    def close(self):
        """關閉連接"""
        if self.conn:
            self.conn.close()
