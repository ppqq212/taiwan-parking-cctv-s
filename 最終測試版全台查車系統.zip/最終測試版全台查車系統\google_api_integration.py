#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google API 整合模組 - 修復版
整合Google Maps、Places、Geocoding等API功能
"""

import json
import time
import webbrowser
from datetime import datetime

try:
    import requests
except ImportError:
    requests = None
    print("警告: requests模組未安裝，Google API功能可能受限")

class GoogleAPIIntegration:
    """
    Google API整合模組
    提供Google Maps、Places、Geocoding、Directions、Distance Matrix等API功能
    """
    
    def __init__(self, api_manager):
        self.api_manager = api_manager
        self.base_urls = {
            "maps": "https://maps.googleapis.com/maps/api",
            "places": "https://maps.googleapis.com/maps/api/place",
            "geocoding": "https://maps.googleapis.com/maps/api/geocode",
            "directions": "https://maps.googleapis.com/maps/api/directions",
            "distance_matrix": "https://maps.googleapis.com/maps/api/distancematrix"
        }
    
    def get_api_key(self, api_type="maps"):
        """獲取API KEY"""
        if self.api_manager:
            return self.api_manager.get_api_key(f"google_{api_type}")
        return ""
    
    def search_parking_nearby(self, location, radius=1000, keyword="停車場"):
        """搜尋附近的停車場"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("places")
            if not api_key:
                return {"error": "Google Places API KEY未設定"}
            
            url = f"{self.base_urls['places']}/nearbysearch/json"
            params = {
                "location": location,  # "緯度,經度" 格式
                "radius": radius,
                "keyword": keyword,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    return self.parse_parking_results(data.get("results", []))
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"搜尋停車場失敗: {e}"}
    
    def parse_parking_results(self, results):
        """解析停車場搜尋結果"""
        parking_list = []
        for place in results:
            parking_info = {
                "name": place.get("name", "未知停車場"),
                "address": place.get("vicinity", "地址未知"),
                "rating": place.get("rating", 0),
                "price_level": place.get("price_level", 0),
                "location": place.get("geometry", {}).get("location", {}),
                "place_id": place.get("place_id", ""),
                "types": place.get("types", [])
            }
            parking_list.append(parking_info)
        return {"parking_list": parking_list, "count": len(parking_list)}
    
    def get_place_details(self, place_id):
        """獲取地點詳細資訊"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("places")
            if not api_key:
                return {"error": "Google Places API KEY未設定"}
            
            url = f"{self.base_urls['places']}/details/json"
            params = {
                "place_id": place_id,
                "fields": "name,formatted_address,rating,price_level,opening_hours,photos",
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    return data.get("result", {})
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"獲取地點詳情失敗: {e}"}
    
    def geocode_address(self, address):
        """地址轉座標"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("geocoding")
            if not api_key:
                return {"error": "Google Geocoding API KEY未設定"}
            
            url = f"{self.base_urls['geocoding']}/json"
            params = {
                "address": address,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    results = data.get("results", [])
                    if results:
                        location = results[0].get("geometry", {}).get("location", {})
                        return {
                            "lat": location.get("lat"),
                            "lng": location.get("lng"),
                            "formatted_address": results[0].get("formatted_address")
                        }
                    else:
                        return {"error": "找不到該地址"}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"地址轉座標失敗: {e}"}
    
    def reverse_geocode(self, lat, lng):
        """座標轉地址"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("geocoding")
            if not api_key:
                return {"error": "Google Geocoding API KEY未設定"}
            
            url = f"{self.base_urls['geocoding']}/json"
            params = {
                "latlng": f"{lat},{lng}",
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    results = data.get("results", [])
                    if results:
                        return {
                            "formatted_address": results[0].get("formatted_address"),
                            "address_components": results[0].get("address_components", [])
                        }
                    else:
                        return {"error": "找不到該座標的地址"}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"座標轉地址失敗: {e}"}
    
    def get_directions(self, origin, destination, mode="driving"):
        """獲取路線規劃"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("directions")
            if not api_key:
                return {"error": "Google Directions API KEY未設定"}
            
            url = f"{self.base_urls['directions']}/json"
            params = {
                "origin": origin,
                "destination": destination,
                "mode": mode,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    routes = data.get("routes", [])
                    if routes:
                        route = routes[0]
                        legs = route.get("legs", [])
                        if legs:
                            leg = legs[0]
                            return {
                                "distance": leg.get("distance", {}).get("text", ""),
                                "duration": leg.get("duration", {}).get("text", ""),
                                "start_address": leg.get("start_address", ""),
                                "end_address": leg.get("end_address", ""),
                                "steps": leg.get("steps", [])
                            }
                    return {"error": "找不到路線"}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"路線規劃失敗: {e}"}
    
    def get_distance_matrix(self, origins, destinations):
        """獲取距離矩陣"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("distance_matrix")
            if not api_key:
                return {"error": "Google Distance Matrix API KEY未設定"}
            
            url = f"{self.base_urls['distance_matrix']}/json"
            params = {
                "origins": origins,
                "destinations": destinations,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    rows = data.get("rows", [])
                    if rows:
                        elements = rows[0].get("elements", [])
                        if elements:
                            element = elements[0]
                            return {
                                "distance": element.get("distance", {}).get("text", ""),
                                "duration": element.get("duration", {}).get("text", ""),
                                "status": element.get("status", "")
                            }
                    return {"error": "找不到距離資訊"}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"距離計算失敗: {e}"}
    
    def open_google_maps(self, location=None, destination=None):
        """開啟Google Maps"""
        try:
            if location and destination:
                # 路線規劃
                url = f"https://www.google.com/maps/dir/{location}/{destination}"
            elif location:
                # 單一地點
                url = f"https://www.google.com/maps/search/{location}"
            else:
                # 預設地圖
                url = "https://www.google.com/maps"
            
            webbrowser.open(url)
            return {"success": True, "url": url}
            
        except Exception as e:
            return {"error": f"開啟Google Maps失敗: {e}"}
    
    def create_embedded_map_url(self, location, zoom=15, size="600x400"):
        """創建嵌入式地圖URL"""
        try:
            api_key = self.get_api_key("maps")
            if not api_key:
                return {"error": "Google Maps API KEY未設定"}
            
            # 將地址轉換為座標
            if isinstance(location, str):
                geocode_result = self.geocode_address(location)
                if "error" in geocode_result:
                    return geocode_result
                lat = geocode_result.get("lat")
                lng = geocode_result.get("lng")
            else:
                lat, lng = location
            
            # 創建嵌入式地圖URL
            embed_url = f"https://www.google.com/maps/embed/v1/place"
            params = {
                "key": api_key,
                "q": f"{lat},{lng}",
                "zoom": zoom
            }
            
            param_string = "&".join([f"{k}={v}" for k, v in params.items()])
            full_url = f"{embed_url}?{param_string}"
            
            return {"success": True, "embed_url": full_url}
            
        except Exception as e:
            return {"error": f"創建嵌入式地圖失敗: {e}"}
    
    def search_nearby_services(self, location, service_type, radius=1000):
        """搜尋附近服務"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("places")
            if not api_key:
                return {"error": "Google Places API KEY未設定"}
            
            url = f"{self.base_urls['places']}/nearbysearch/json"
            params = {
                "location": location,
                "radius": radius,
                "type": service_type,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    results = data.get("results", [])
                    services = []
                    for place in results:
                        service_info = {
                            "name": place.get("name", ""),
                            "address": place.get("vicinity", ""),
                            "rating": place.get("rating", 0),
                            "location": place.get("geometry", {}).get("location", {}),
                            "place_id": place.get("place_id", "")
                        }
                        services.append(service_info)
                    return {"services": services, "count": len(services)}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路請求失敗: {e}"}
        except Exception as e:
            return {"error": f"搜尋附近服務失敗: {e}"}
    
    def get_place_photos(self, place_id, max_photos=5):
        """獲取地點照片"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("places")
            if not api_key:
                return {"error": "Google Places API KEY未設定"}
            
            # 先獲取地點詳情
            details_result = self.get_place_details(place_id)
            if "error" in details_result:
                return details_result
            
            photos = details_result.get("photos", [])
            photo_urls = []
            
            for i, photo in enumerate(photos[:max_photos]):
                photo_reference = photo.get("photo_reference")
                if photo_reference:
                    photo_url = f"https://maps.googleapis.com/maps/api/place/photo"
                    params = {
                        "maxwidth": 400,
                        "photo_reference": photo_reference,
                        "key": api_key
                    }
                    param_string = "&".join([f"{k}={v}" for k, v in params.items()])
                    full_url = f"{photo_url}?{param_string}"
                    photo_urls.append(full_url)
            
            return {"photos": photo_urls, "count": len(photo_urls)}
            
        except Exception as e:
            return {"error": f"獲取地點照片失敗: {e}"}
    
    def test_api_connection(self):
        """測試API連接"""
        try:
            if not requests:
                return {"error": "requests模組未安裝"}
            
            api_key = self.get_api_key("geocoding")
            if not api_key:
                return {"error": "Google API KEY未設定"}
            
            # 測試地理編碼API
            test_address = "台北101"
            url = f"{self.base_urls['geocoding']}/json"
            params = {
                "address": test_address,
                "key": api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK":
                    return {"success": True, "message": "Google API連接正常"}
                else:
                    return {"error": f"API錯誤: {data.get('status')}"}
            else:
                return {"error": f"HTTP錯誤: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"網路連接失敗: {e}"}
        except Exception as e:
            return {"error": f"API測試失敗: {e}"}
