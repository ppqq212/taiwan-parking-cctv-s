# 最終測試版全台查車系統 
 
## 系統特色 
 
- 🚗 全台停車場搜尋 
- 🔍 車牌號碼查詢 
- 🗺️ Google Maps整合 
- 🤖 AI智能功能 
- 📊 政府API整合 
 
## 安裝步驟 
 
1. 解壓縮檔案 
2. 安裝Python依賴: pip install -r requirements.txt 
3. 執行啟動系統.bat 
 
## 注意事項 
 
- 需要Python 3.7+環境 
- 所有API KEY已預配置 
- 支援Windows 10/11 
