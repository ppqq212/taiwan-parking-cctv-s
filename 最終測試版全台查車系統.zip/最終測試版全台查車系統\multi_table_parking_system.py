#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多表版停車場搜尋系統 - 修復版
整合全台停車場、監理站、政府API
支援地區分類、多種數據查看
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import time
import sqlite3
from datetime import datetime
import random

try:
    import requests
except ImportError:
    requests = None
    print("警告: requests模組未安裝，部分功能可能無法使用")

try:
    from advanced_parking_features import AdvancedParkingFeatures
except ImportError:
    AdvancedParkingFeatures = None
    print("警告: advanced_parking_features模組未找到，高級功能將被禁用")

try:
    import webbrowser
    from tkinter import messagebox
except ImportError:
    webbrowser = None
    messagebox = None
    print("警告: webbrowser或messagebox模組未找到，相關功能將被禁用")

try:
    from api_key_manager import APIKeyManager
except ImportError:
    APIKeyManager = None
    print("警告: api_key_manager模組未找到，API管理功能將被禁用")

try:
    from ai_features import AIFeatures
except ImportError:
    AIFeatures = None
    print("警告: ai_features模組未找到，AI功能將被禁用")

class MultiTableParkingSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("多表版停車場搜尋系統 - 全台整合版")
        self.root.geometry("1600x1000")
        
        # 暗色主題配置
        self.setup_dark_theme()
        
        # 系統配置
        self.setup_database()
        self.setup_apis()
        
        # 高級功能模組
        if AdvancedParkingFeatures:
            self.advanced_features = AdvancedParkingFeatures(self)
        else:
            self.advanced_features = None
        
        # API管理模組
        if APIKeyManager:
            self.api_manager = APIKeyManager(self)
        else:
            self.api_manager = None
        
        # AI功能模組
        if AIFeatures:
            self.ai_features = AIFeatures(self)
        else:
            self.ai_features = None
        
        # 直接進入系統，無需登入
        self.current_user = "系統管理員"
        self.user_permissions = "admin"
        
        self.setup_ui()
    
    def setup_dark_theme(self):
        """設置暗色主題"""
        # 暗色主題配色
        self.colors = {
            'bg': '#2b2b2b',           # 主背景
            'fg': '#ffffff',           # 主文字
            'select_bg': '#404040',    # 選中背景
            'select_fg': '#ffffff',    # 選中文字
            'button_bg': '#404040',    # 按鈕背景
            'button_fg': '#ffffff',    # 按鈕文字
            'entry_bg': '#404040',     # 輸入框背景
            'entry_fg': '#ffffff',     # 輸入框文字
            'frame_bg': '#3c3c3c',     # 框架背景
            'tree_bg': '#404040',      # 樹狀圖背景
            'tree_fg': '#ffffff',      # 樹狀圖文字
            'header_bg': '#505050',    # 標題背景
            'header_fg': '#ffffff'     # 標題文字
        }
        
        # 設置主視窗背景
        self.root.configure(bg=self.colors['bg'])
        
        # 設置TTK樣式
        style = ttk.Style()
        style.theme_use('clam')
        
        # 配置TTK樣式
        style.configure('TNotebook', background=self.colors['bg'])
        style.configure('TNotebook.Tab', background=self.colors['frame_bg'], foreground=self.colors['fg'])
        style.map('TNotebook.Tab', background=[('selected', self.colors['select_bg'])])
        
        style.configure('TFrame', background=self.colors['bg'])
        style.configure('TLabel', background=self.colors['bg'], foreground=self.colors['fg'])
        style.configure('TButton', background=self.colors['button_bg'], foreground=self.colors['button_fg'])
        style.configure('TEntry', fieldbackground=self.colors['entry_bg'], foreground=self.colors['entry_fg'])
        style.configure('TCombobox', fieldbackground=self.colors['entry_bg'], foreground=self.colors['entry_fg'])
        
        # 樹狀圖樣式
        style.configure('Treeview', background=self.colors['tree_bg'], foreground=self.colors['tree_fg'])
        style.configure('Treeview.Heading', background=self.colors['header_bg'], foreground=self.colors['header_fg'])
    
    def setup_database(self):
        """設置資料庫"""
        self.conn = sqlite3.connect('multi_table_parking.db', check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        # 創建基本表格
        self.create_tables()
        
        # 初始化數據
        self.initialize_data()
    
    def create_tables(self):
        """創建資料庫表格"""
        # 用戶表
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                permissions TEXT DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 查詢記錄表
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS query_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                query_type TEXT,
                query_content TEXT,
                result_count INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 車輛追蹤表
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS vehicle_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                location TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'active'
            )
        ''')
        
        # 車牌資料庫
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS license_plate_database (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT UNIQUE NOT NULL,
                owner_name TEXT,
                vehicle_type TEXT,
                registration_date TEXT,
                status TEXT DEFAULT 'active'
            )
        ''')
        
        # 東部停車場資料
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS eastern_parking_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                region TEXT NOT NULL,
                parking_name TEXT NOT NULL,
                address TEXT,
                total_spaces INTEGER,
                available_spaces INTEGER,
                hourly_rate REAL,
                status TEXT DEFAULT 'active'
            )
        ''')
        
        self.conn.commit()
    
    def initialize_data(self):
        """初始化數據"""
        # 初始化車牌資料庫
        self.initialize_license_plate_database()
        
        # 初始化東部停車場資料
        self.initialize_eastern_parking_data()
    
    def initialize_license_plate_database(self):
        """初始化車牌資料庫"""
        # 檢查是否已有數據
        self.cursor.execute("SELECT COUNT(*) FROM license_plate_database")
        count = self.cursor.fetchone()[0]
        
        if count == 0:
            # 插入示例車牌數據
            license_plates = [
                ("ABC-1234", "張三", "轎車", "2020-01-15", "active"),
                ("DEF-5678", "李四", "休旅車", "2019-03-20", "active"),
                ("GHI-9012", "王五", "貨車", "2021-06-10", "active"),
                ("JKL-3456", "陳六", "機車", "2022-02-28", "active"),
                ("MNO-7890", "林七", "轎車", "2020-11-12", "active"),
                ("PQR-2468", "黃八", "休旅車", "2021-09-05", "active"),
                ("STU-1357", "劉九", "貨車", "2019-12-03", "active"),
                ("VWX-9753", "吳十", "機車", "2022-04-18", "active"),
                ("YZA-8642", "鄭十一", "轎車", "2021-07-25", "active"),
                ("BCD-7531", "許十二", "休旅車", "2020-05-30", "active")
            ]
            
            self.cursor.executemany(
                "INSERT INTO license_plate_database (plate_number, owner_name, vehicle_type, registration_date, status) VALUES (?, ?, ?, ?, ?)",
                license_plates
            )
            self.conn.commit()
            print("已初始化 10 個車牌號碼到資料庫")
        else:
            print(f"車牌資料庫已有 {count} 筆資料")
    
    def initialize_eastern_parking_data(self):
        """初始化東部停車場資料"""
        # 檢查是否已有數據
        self.cursor.execute("SELECT COUNT(*) FROM eastern_parking_data")
        count = self.cursor.fetchone()[0]
        
        if count == 0:
            # 插入東部停車場數據
            parking_data = [
                ("花蓮縣", "花蓮車站停車場", "花蓮市國聯一路100號", 200, 150, 30.0),
                ("花蓮縣", "花蓮市公所停車場", "花蓮市林森路252號", 80, 60, 25.0),
                ("花蓮縣", "東大門夜市停車場", "花蓮市中山路50號", 120, 90, 20.0),
                ("宜蘭縣", "宜蘭車站停車場", "宜蘭縣宜蘭市光復路1號", 150, 120, 35.0),
                ("宜蘭縣", "羅東車站停車場", "宜蘭縣羅東鎮中正北路1號", 100, 80, 30.0),
                ("宜蘭縣", "礁溪溫泉停車場", "宜蘭縣礁溪鄉溫泉路1號", 60, 45, 40.0),
                ("台東縣", "台東車站停車場", "台東縣台東市鐵花路369號", 180, 140, 25.0),
                ("台東縣", "知本溫泉停車場", "台東縣卑南鄉溫泉村溫泉路1號", 50, 35, 30.0),
                ("台東縣", "成功漁港停車場", "台東縣成功鎮中山路1號", 40, 30, 20.0)
            ]
            
            self.cursor.executemany(
                "INSERT INTO eastern_parking_data (region, parking_name, address, total_spaces, available_spaces, hourly_rate) VALUES (?, ?, ?, ?, ?, ?)",
                parking_data
            )
            self.conn.commit()
            print("已初始化 9 個東部停車場資料")
        else:
            print(f"東部停車場資料已有 {count} 筆資料")
    
    def setup_apis(self):
        """設置API配置"""
        self.api_configs = {
            "台北市": {
                "base_url": "https://api.taipei.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 1000
            },
            "新北市": {
                "base_url": "https://api.ntpc.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 800
            },
            "桃園市": {
                "base_url": "https://api.tycg.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 600
            },
            "台中市": {
                "base_url": "https://api.taichung.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 700
            },
            "台南市": {
                "base_url": "https://api.tainan.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 500
            },
            "高雄市": {
                "base_url": "https://api.kcg.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 600
            },
            "花蓮縣": {
                "base_url": "https://api.hl.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 300
            },
            "宜蘭縣": {
                "base_url": "https://api.e-land.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 300
            },
            "台東縣": {
                "base_url": "https://api.taitung.gov.tw",
                "parking_api": "/parking/realtime",
                "rate_limit": 300
            }
        }
    
    def setup_ui(self):
        """設置使用者介面"""
        # 主標題
        title_frame = tk.Frame(self.root, bg=self.colors['bg'])
        title_frame.pack(fill=tk.X, padx=20, pady=10)
        
        title_label = tk.Label(title_frame,
                              text="多表版停車場搜尋系統 - 全台整合版",
                              font=("微軟正黑體", 20, "bold"),
                              bg=self.colors['bg'],
                              fg=self.colors['fg'])
        title_label.pack()
        
        subtitle_label = tk.Label(title_frame,
                                 text="整合全台停車場、監理站、政府API | 支援地區分類、多種數據查看",
                                 font=("微軟正黑體", 12),
                                 bg=self.colors['bg'],
                                 fg=self.colors['fg'])
        subtitle_label.pack()
        
        # 主要筆記本
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 創建各個頁面
        self.create_main_tab()
        self.create_license_plate_tab()
        self.create_eastern_parking_tab()
        self.create_system_settings_tab()
        
        # 高級功能頁面
        if self.advanced_features:
            self.create_advanced_features_tabs()
        
        # API管理頁面
        if self.api_manager:
            self.create_api_management_tab()
        
        # AI功能頁面
        if self.ai_features:
            self.create_ai_features_tab()
    
    def create_main_tab(self):
        """創建主頁面"""
        main_frame = ttk.Frame(self.notebook)
        self.notebook.add(main_frame, text="🏠 主頁面")
        
        # 歡迎訊息
        welcome_frame = ttk.LabelFrame(main_frame, text="系統歡迎", padding=20)
        welcome_frame.pack(fill=tk.X, padx=20, pady=10)
        
        welcome_text = f"""
歡迎使用多表版停車場搜尋系統！

🎯 系統特色：
• 整合全台停車場資訊
• 支援地區分類查看
• 內建車牌號碼資料庫
• 東部縣市停車場資料
• 政府API整合
• 高級功能模組

👤 當前用戶：{self.current_user}
🔑 權限等級：{self.user_permissions}
⏰ 登入時間：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        welcome_label = tk.Label(welcome_frame, text=welcome_text, justify=tk.LEFT,
                                font=("微軟正黑體", 11), bg=self.colors['bg'], fg=self.colors['fg'])
        welcome_label.pack(anchor=tk.W)
        
        # 快速功能
        quick_frame = ttk.LabelFrame(main_frame, text="快速功能", padding=20)
        quick_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 功能按鈕
        button_frame = tk.Frame(quick_frame, bg=self.colors['bg'])
        button_frame.pack(fill=tk.X)
        
        tk.Button(button_frame, text="🔍 搜尋停車場", command=self.search_parking,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg'],
                 width=15, height=2).pack(side=tk.LEFT, padx=10, pady=5)
        
        tk.Button(button_frame, text="🚗 車牌查詢", command=self.query_license_plate,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg'],
                 width=15, height=2).pack(side=tk.LEFT, padx=10, pady=5)
        
        tk.Button(button_frame, text="📍 東部停車場", command=self.view_eastern_parking,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg'],
                 width=15, height=2).pack(side=tk.LEFT, padx=10, pady=5)
        
        tk.Button(button_frame, text="⚙️ 系統設定", command=self.open_system_settings,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg'],
                 width=15, height=2).pack(side=tk.LEFT, padx=10, pady=5)
    
    def create_license_plate_tab(self):
        """創建車牌查詢頁面"""
        license_frame = ttk.Frame(self.notebook)
        self.notebook.add(license_frame, text="🚗 車牌查詢")
        
        # 搜尋區域
        search_frame = ttk.LabelFrame(license_frame, text="車牌號碼搜尋", padding=20)
        search_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # 搜尋輸入
        input_frame = tk.Frame(search_frame, bg=self.colors['bg'])
        input_frame.pack(fill=tk.X)
        
        tk.Label(input_frame, text="車牌號碼:", font=("微軟正黑體", 12),
                bg=self.colors['bg'], fg=self.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.license_entry = tk.Entry(input_frame, font=("微軟正黑體", 12),
                                     bg=self.colors['entry_bg'], fg=self.colors['entry_fg'],
                                     width=20)
        self.license_entry.pack(side=tk.LEFT, padx=5)
        
        tk.Button(input_frame, text="🔍 搜尋", command=self.search_license_plate_ui,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg']).pack(side=tk.LEFT, padx=10)
        
        tk.Button(input_frame, text="📋 顯示全部", command=self.show_all_license_plates,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg']).pack(side=tk.LEFT, padx=5)
        
        # 結果顯示
        result_frame = ttk.LabelFrame(license_frame, text="搜尋結果", padding=20)
        result_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 結果樹狀圖
        columns = ('車牌號碼', '車主姓名', '車輛類型', '登記日期', '狀態')
        self.license_tree = ttk.Treeview(result_frame, columns=columns, show='headings', height=15)
        
        for col in columns:
            self.license_tree.heading(col, text=col)
            self.license_tree.column(col, width=120)
        
        license_scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.license_tree.yview)
        self.license_tree.configure(yscrollcommand=license_scrollbar.set)
        
        self.license_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        license_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def create_eastern_parking_tab(self):
        """創建東部停車場頁面"""
        eastern_frame = ttk.Frame(self.notebook)
        self.notebook.add(eastern_frame, text="📍 東部停車場")
        
        # 地區選擇
        region_frame = ttk.LabelFrame(eastern_frame, text="地區選擇", padding=20)
        region_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(region_frame, text="選擇地區:", font=("微軟正黑體", 12),
                bg=self.colors['bg'], fg=self.colors['fg']).pack(side=tk.LEFT, padx=5)
        
        self.region_combo = ttk.Combobox(region_frame, values=["花蓮縣", "宜蘭縣", "台東縣"],
                                       state="readonly", width=15)
        self.region_combo.pack(side=tk.LEFT, padx=5)
        self.region_combo.set("花蓮縣")
        
        tk.Button(region_frame, text="🔍 查詢", command=self.search_eastern_parking,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg']).pack(side=tk.LEFT, padx=10)
        
        # 停車場列表
        parking_frame = ttk.LabelFrame(eastern_frame, text="停車場列表", padding=20)
        parking_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        columns = ('地區', '停車場名稱', '地址', '總車位', '可用車位', '每小時費用')
        self.parking_tree = ttk.Treeview(parking_frame, columns=columns, show='headings', height=15)
        
        for col in columns:
            self.parking_tree.heading(col, text=col)
            self.parking_tree.column(col, width=120)
        
        parking_scrollbar = ttk.Scrollbar(parking_frame, orient=tk.VERTICAL, command=self.parking_tree.yview)
        self.parking_tree.configure(yscrollcommand=parking_scrollbar.set)
        
        self.parking_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        parking_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 初始化顯示
        self.load_eastern_parking_data()
    
    def create_system_settings_tab(self):
        """創建系統設定頁面"""
        settings_frame = ttk.Frame(self.notebook)
        self.notebook.add(settings_frame, text="⚙️ 系統設定")
        
        # 系統資訊
        info_frame = ttk.LabelFrame(settings_frame, text="系統資訊", padding=20)
        info_frame.pack(fill=tk.X, padx=20, pady=10)
        
        info_text = f"""
系統版本：多表版停車場搜尋系統 v2.0
資料庫狀態：已連接
API狀態：已配置
用戶權限：{self.user_permissions}
最後更新：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        info_label = tk.Label(info_frame, text=info_text, justify=tk.LEFT,
                             font=("微軟正黑體", 11), bg=self.colors['bg'], fg=self.colors['fg'])
        info_label.pack(anchor=tk.W)
        
        # 功能設定
        feature_frame = ttk.LabelFrame(settings_frame, text="功能設定", padding=20)
        feature_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 設定選項
        options_frame = tk.Frame(feature_frame, bg=self.colors['bg'])
        options_frame.pack(fill=tk.X)
        
        tk.Label(options_frame, text="主題模式:", font=("微軟正黑體", 12),
                bg=self.colors['bg'], fg=self.colors['fg']).grid(row=0, column=0, sticky=tk.W, padx=5)
        
        self.theme_var = tk.StringVar(value="暗色")
        theme_combo = ttk.Combobox(options_frame, textvariable=self.theme_var,
                                  values=["暗色", "亮色", "自動"], state="readonly", width=15)
        theme_combo.grid(row=0, column=1, padx=5)
        
        tk.Label(options_frame, text="字體大小:", font=("微軟正黑體", 12),
                bg=self.colors['bg'], fg=self.colors['fg']).grid(row=1, column=0, sticky=tk.W, padx=5)
        
        self.font_size_var = tk.StringVar(value="12")
        font_combo = ttk.Combobox(options_frame, textvariable=self.font_size_var,
                                 values=["10", "12", "14", "16", "18"], state="readonly", width=15)
        font_combo.grid(row=1, column=1, padx=5)
        
        # 按鈕
        button_frame = tk.Frame(feature_frame, bg=self.colors['bg'])
        button_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(button_frame, text="💾 儲存設定", command=self.save_settings,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg']).pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="🔄 重置設定", command=self.reset_settings,
                 font=("微軟正黑體", 12), bg=self.colors['button_bg'], fg=self.colors['button_fg']).pack(side=tk.LEFT, padx=5)
    
    def create_advanced_features_tabs(self):
        """創建高級功能頁面"""
        if not self.advanced_features:
            return
        
        # 數據來源頁面
        self.advanced_features.create_data_source_tab(self.notebook)
        
        # 地圖整合頁面
        self.advanced_features.create_map_integration_tab(self.notebook)
        
        # CCTV直播頁面
        self.advanced_features.create_cctv_tab(self.notebook)
        
        # 介面自訂頁面
        self.advanced_features.create_ui_customization_tab(self.notebook)
    
    def create_api_management_tab(self):
        """創建API管理頁面"""
        if not self.api_manager:
            return
        
        api_frame = ttk.Frame(self.notebook)
        self.notebook.add(api_frame, text="🔑 API管理")
        
        # API管理功能
        self.api_manager.create_api_management_tab(api_frame)
    
    def create_ai_features_tab(self):
        """創建AI功能頁面"""
        if not self.ai_features:
            return
        
        ai_frame = ttk.Frame(self.notebook)
        self.notebook.add(ai_frame, text="🤖 AI功能")
        
        # AI功能介面
        self.ai_features.create_ai_features_ui(ai_frame)
    
    def search_parking(self):
        """搜尋停車場"""
        if messagebox:
            messagebox.showinfo("搜尋停車場", "停車場搜尋功能已啟動")
        else:
            print("停車場搜尋功能已啟動")
    
    def query_license_plate(self):
        """查詢車牌號碼"""
        if messagebox:
            messagebox.showinfo("車牌查詢", "車牌查詢功能已啟動")
        else:
            print("車牌查詢功能已啟動")
    
    def view_eastern_parking(self):
        """查看東部停車場"""
        if messagebox:
            messagebox.showinfo("東部停車場", "東部停車場功能已啟動")
        else:
            print("東部停車場功能已啟動")
    
    def open_system_settings(self):
        """開啟系統設定"""
        self.notebook.select(3)  # 切換到系統設定頁面
    
    def search_license_plate_ui(self):
        """車牌搜尋UI"""
        plate_number = self.license_entry.get().strip()
        if not plate_number:
            if messagebox:
                messagebox.showwarning("警告", "請輸入車牌號碼")
            return
        
        # 清除現有結果
        for item in self.license_tree.get_children():
            self.license_tree.delete(item)
        
        # 搜尋車牌
        results = self.search_license_plate(plate_number, "all")
        
        if results:
            for result in results:
                self.license_tree.insert("", "end", values=(
                    result["plate_number"],
                    result["owner_name"],
                    result["vehicle_type"],
                    result["registration_date"],
                    result["status"]
                ))
        else:
            if messagebox:
                messagebox.showinfo("搜尋結果", "未找到相關車牌資料")
    
    def search_license_plate(self, keyword, filter_type):
        """搜尋車牌號碼"""
        try:
            # 模擬搜尋結果
            results = []
            
            # 搜尋內建資料庫
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM license_plate_database WHERE plate_number LIKE ?", (f"%{keyword}%",))
            rows = cursor.fetchall()
            
            for row in rows:
                results.append({
                    "plate_number": row[1],
                    "owner_name": row[2],
                    "vehicle_type": row[3],
                    "registration_date": row[4],
                    "status": row[5]
                })
            
            return results
            
        except Exception as e:
            print(f"搜尋車牌失敗: {e}")
            return []
    
    def show_all_license_plates(self):
        """顯示所有車牌"""
        # 清除現有結果
        for item in self.license_tree.get_children():
            self.license_tree.delete(item)
        
        # 載入所有車牌
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM license_plate_database")
        rows = cursor.fetchall()
        
        for row in rows:
            self.license_tree.insert("", "end", values=(
                row[1],  # plate_number
                row[2],  # owner_name
                row[3],  # vehicle_type
                row[4],  # registration_date
                row[5]   # status
            ))
    
    def search_eastern_parking(self):
        """搜尋東部停車場"""
        region = self.region_combo.get()
        if not region:
            if messagebox:
                messagebox.showwarning("警告", "請選擇地區")
            return
        
        # 清除現有結果
        for item in self.parking_tree.get_children():
            self.parking_tree.delete(item)
        
        # 搜尋停車場
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM eastern_parking_data WHERE region = ?", (region,))
        rows = cursor.fetchall()
        
        for row in rows:
            self.parking_tree.insert("", "end", values=(
                row[1],  # region
                row[2],  # parking_name
                row[3],  # address
                row[4],  # total_spaces
                row[5],  # available_spaces
                f"${row[6]}"  # hourly_rate
            ))
    
    def load_eastern_parking_data(self):
        """載入東部停車場資料"""
        # 清除現有結果
        for item in self.parking_tree.get_children():
            self.parking_tree.delete(item)
        
        # 載入所有資料
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM eastern_parking_data")
        rows = cursor.fetchall()
        
        for row in rows:
            self.parking_tree.insert("", "end", values=(
                row[1],  # region
                row[2],  # parking_name
                row[3],  # address
                row[4],  # total_spaces
                row[5],  # available_spaces
                f"${row[6]}"  # hourly_rate
            ))
    
    def save_settings(self):
        """儲存設定"""
        if messagebox:
            messagebox.showinfo("成功", "設定已儲存")
        else:
            print("設定已儲存")
    
    def reset_settings(self):
        """重置設定"""
        self.theme_var.set("暗色")
        self.font_size_var.set("12")
        if messagebox:
            messagebox.showinfo("成功", "設定已重置")
        else:
            print("設定已重置")
    
    def open_website(self, url):
        """開啟網站"""
        try:
            if webbrowser:
                webbrowser.open(url)
            else:
                print(f"無法開啟網站: {url}")
        except Exception as e:
            print(f"開啟網站失敗: {e}")
    def troubleshoot(self):
        """排解常見問題"""
        issues = []
        # 檢查 requests 模組
        if requests is None:
            issues.append("requests 模組未安裝，部分API功能將無法使用。")
        # 檢查高級功能模組
        if AdvancedParkingFeatures is None:
            issues.append("advanced_parking_features 模組未找到，高級功能將被禁用。")
        # 檢查 API 管理模組
        if APIKeyManager is None:
            issues.append("api_key_manager 模組未找到，API金鑰管理功能將被禁用。")
        # 檢查 AI 功能模組
        if AIFeatures is None:
            issues.append("ai_features 模組未找到，AI功能將被禁用。")
        # 檢查資料庫連線
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT 1")
        except Exception as e:
            issues.append(f"資料庫連線異常: {e}")
        # 檢查網路連線
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=2)
        except Exception:
            issues.append("偵測到網路連線異常，部分即時功能可能無法使用。")
        # 顯示結果
        if not issues:
            msg = "系統運作正常，未偵測到明顯問題。"
        else:
            msg = "排解結果：\n" + "\n".join(issues)
        if messagebox:
            messagebox.showinfo("排解結果", msg)
        else:
            print(msg)

def main():
    root = tk.Tk()
    MultiTableParkingSystem(root)
    root.mainloop()

if __name__ == "__main__":
    main()
